sap.ui.define([
	"sap/m/MessageToast",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	'sap/ui/integration/Host'
], function (MessageToast, Controller, JSONModel, Host) {
	"use strict";

	return Controller.extend("ns.creatematerials_mm01.Card", {
		onInit: function () {
			var oModel = new JSONModel({
				"cities": [
					{
						"text": "Berlin",
						"key": "BR"
					},
					{
						"text": "London",
						"key": "LN"
					},
					{
						"text": "Madrid",
						"key": "MD"
					},
					{
						"text": "Prague",
						"key": "PR"
					},
					{
						"text": "Paris",
						"key": "PS"
					},
					{
						"text": "Sofia",
						"key": "SF"
					},
					{
						"text": "Vienna",
						"key": "VN"
					}
				]
			});
			this.getView().setModel(oModel);

			let oController = this;
			let oCardInstance = this.getOwnerComponent().getComponentData().__sapUiIntegration_card;

			
			
			oCardInstance.request({
				"url": "{{destinations.ES5}}/sap/opu/odata/iwbep/GWSAMPLE_BASIC/ContactSet",
				"method": "GET",
				"parameters": {
					"$format": "json",
					"$top": 10
				},
				"withCredentials" : true
			}).then(function(oRes){

				 console.log(oRes);

				/*let aResults = oRes.d.results;
				let oModel = new sap.ui.model.json.JSONModel(aResults);
				let oView = oController.getView();
				oView.setModel(oModel); 

				oCard.hideLoadingPlaceholders(); */

			}).catch(function(error){
				/* oCard.showBlockingMessage({
					type: CardBlockingMessageType.Error,
					title: "Unable to load data"
				});
				oCard.hideLoadingPlaceholders(); */
			})
		}
	});
});