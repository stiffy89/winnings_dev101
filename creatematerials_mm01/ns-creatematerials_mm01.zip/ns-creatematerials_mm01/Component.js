sap.ui.define(['sap/ui/core/UIComponent'],
	function(UIComponent) {
	"use strict";

	var Component = UIComponent.extend("ns.creatematerials_mm01.Component", {

		metadata : {
			manifest: "json"
		}
	});

	return Component;

});
