sap.ui.define(['sap/ui/core/UIComponent'],
	function(UIComponent) {
	"use strict";

	var Component = UIComponent.extend("ns.welcome_card1.Component", {

		metadata : {
			manifest: "json"
		}
	});

	return Component;

});
