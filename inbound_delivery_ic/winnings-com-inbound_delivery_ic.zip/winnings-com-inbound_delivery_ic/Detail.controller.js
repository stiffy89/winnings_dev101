sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";
	
	let oController;




	return Controller.extend("winnings.com.inbound_delivery_ic.Detail", {
		onInit: function() {
			const orderRoute = this.getOwnerComponent().getRouter().getRoute("detail");
  			orderRoute.attachPatternMatched(this.onPatternMatched, this);
		},

		onPatternMatched: function (oPassedData) {
			console.log(oPassedData);
		},

		toSupplierDetail: function (oEvent) {
			this.getOwnerComponent().getRouter().navTo('deliveries');
		}
	});
});